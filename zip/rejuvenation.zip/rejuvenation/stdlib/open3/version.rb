module Open3
  VERSION = "0.1.1"
end
