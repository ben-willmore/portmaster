
## Notes

A big, meaty thanks to [Team Meat](http://www.supermeatboy.com/) (the dynamic duo of Tommy Refenes and Edmund McMillen) and the maestro of melody, Danny Baranowsky, for creating this game. And let's not forget [fexofenadine](https://github.com/fexofenadine), who despite being named after an antihistamine, didn't sneeze at the challenge of porting this to PortMaster. Bless you, fexofenadine!

- If you're a proud owner of the game on Steam, do a little copy-paste dance! Move the Steam version of Super Meat Boy (for Linux) game files to the `ports/supermeatboy/gamedata` directory. Easy peasy, meaty squeezy!

- For our Windows friends, you can snatch the Linux game files right from your Steam console. Just run this magic spell: `download_depot 40800 40802 6556596646716197166`. Abracadabra, and the files are yours!

- If you've got the Humble version, just place your `supermeatboy-linux-11112013-bin` file in the `ports/supermeatboy/gamedata` directory. It'll do a little unpacking dance on its first run. Just like opening a present!

Note: RG552 is currently not supported