## Notes

Huge thanks to the creators of Pokemon Reborn. Check out their page [here.](https://www.rebornevo.com/pr/development/) Another thanks goes out to [Dokoma](https://github.com/dokoma) for compiling mkxp. 

Pokemon Reborn requires a lot of ram. The game has been patched for lower usage but keep this in mind, save often.

## Controls

| Button | Action |
|--|--| 
|D-Pad|Walk|
|A|Select|
|B|Back/Menu|
|X|Run/Walk|
|Y|Mega/Sort/Misc|
|L1+R1|Next/Previous Page|
|L2|Ready Items|
|R2|Quicksave|
|D-paddown+start| Text Interactive Mode|


