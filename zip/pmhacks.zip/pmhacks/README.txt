This uses HackSDL to enable external controllers for relevant games.
