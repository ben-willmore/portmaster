module ErrorHighlight
  VERSION = "0.3.0"
end
