#!/bin/bash

../launcher/launcher.py
#frotz "../gamedata/Ad Verbum.z5"
