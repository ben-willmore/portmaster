require_relative "error_highlight/base"
require_relative "error_highlight/core_ext"
