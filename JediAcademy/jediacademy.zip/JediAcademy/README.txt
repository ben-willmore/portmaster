Star Wars Jedi Knight - Jedi Academy Portmaster ReadMe
*Based on the work from: https://github.com/JACoders/OpenJK
*Forked to compile for PortMaster: https://github.com/brooksytech/OpenJK-RG552
*This requires Portmaster to be installed to work: https://351elec.de/PortMaster
*This will technically run on rk3326 devices (rg351p, rgb10max, etc) but perfomance will be to slow. 
*Place your pk3 files in base/
	They should read as follows:
		base/
			assets0.pk3
			assets1.pk3
			assets2.pk3
