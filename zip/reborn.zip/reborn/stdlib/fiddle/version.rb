module Fiddle
  VERSION = "1.1.0"
end
